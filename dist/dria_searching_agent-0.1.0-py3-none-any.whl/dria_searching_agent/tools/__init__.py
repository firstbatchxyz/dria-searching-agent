from dotenv import load_dotenv

# Load environment variables as soon as any tools module is imported
load_dotenv()