


def main():
    print("Hello, I am a searching agent")